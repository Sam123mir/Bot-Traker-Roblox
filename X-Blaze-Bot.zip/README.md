# X-Blaze | Roblox Version Monitor

Monitor de versiones de Roblox profesional con historial, comparativas y notificaciones multilingües.

## 🚀 Despliegue en fps.ms (Sin Tarjeta)

`fps.ms` es altamente recomendado para bots de Discord pequeños. Es gratis y no requiere tarjeta.

1.  **Entrar**: Ve a [fps.ms](https://fps.ms/) e inicia sesión con Discord.
2.  **Crear Servidor**: 
    - Ve a "Servers" -> "Create New".
    - Selecciona **Python** como "Egg".
    - Elige una ubicación (Location) disponible.
    - Recursos: Dale los recursos gratuitos básicos (128MB-256MB RAM son suficientes).
3.  **Subir Archivos**: 
    - Comprime el contenido de esta carpeta en un `.zip` (omite `logs/` y `data/`).
    - En el panel de `fps.ms`, ve a **Files** -> **Upload** y sube el `.zip`.
    - Dale click derecho al zip y selecciona **Unarchive**.
4.  **Configuración (Startup)**:
    - Ve a la pestaña **Startup**.
    - **Startup Command**: Asegúrate de que diga `python bot.py`.
    - **Variables**: Pon tu token de Discord en la sección de variables si te lo solicita el panel.
5.  **Instalación**: El panel detectará `requirements.txt` y lo instalará. Si ves errores, usa la consola: `pip install -r requirements.txt`.
6.  **Mantener online**: Recuerda que en el plan gratis de `fps.ms`, debes entrar al panel una vez cada 24h para darle al botón de **Renew** (es un click rápido).

## 🛠️ Comandos

- `/version`: Historial de los últimos 7 días.
- `/check`: Estado actual de plataformas.
- `/download`: Links de descarga directa.
- `/compare`: Compara versiones.
- `/ping`: Latencia y diagnóstico.

## 📁 Estructura

- `core/`: Lógica de detección e historial.
- `data/`: JSONs de persistencia.
- `logs/`: Logs del sistema.
- `bot.py`: Punto de entrada principal.

---

## ⚡ Instalación rápida

```bash
pip install -r requirements.txt
```

---

## 🚀 Uso

### Iniciar el monitor
```bash
python monitor.py
```

### Probar todos los embeds
```bash
python test_embeds.py
```

### Probar solo una plataforma
```bash
python test_embeds.py WindowsPlayer
python test_embeds.py iOS
```

---

## ⚙️ Configuración (`config.py`)

| Variable | Descripción | Default |
|---|---|---|
| `WEBHOOK_URL` | Webhook principal de Discord | — |
| `WEBHOOK_LOGS_URL` | Webhook para errores (opcional) | `None` |
| `CHECK_INTERVAL` | Segundos entre chequeos | `300` (5 min) |
| `HEARTBEAT_EVERY` | Segundos entre logs de vida | `3600` (1 hora) |
| `RETRY_ATTEMPTS` | Reintentos ante error de red | `3` |

---

## 🖥️ Plataformas soportadas

| Clave | Plataforma | Fuente de datos |
|---|---|---|
| `WindowsPlayer` | Windows PC | Roblox Client Settings API |
| `MacPlayer` | macOS | Roblox Client Settings API |
| `AndroidApp` | Android | Roblox Client Settings API |
| `iOS` | iPhone / iPad | Apple iTunes Lookup API |

---

## 🌐 Endpoints utilizados

- **Windows / Mac / Android:** `https://clientsettings.roblox.com/v2/client-version/{key}`
- **iOS:** `https://itunes.apple.com/lookup?bundleId=com.roblox.roblox&country=us`

---

## 🛡️ Características

- Escritura atómica en `versions.json` (sin corrupción ante reinicios)
- Reintentos automáticos con backoff ante errores de red
- Manejo de rate-limit de Discord (429)
- Apagado limpio con `Ctrl+C` o señal `SIGTERM`
- Log dual: consola + archivo `monitor.log`
- Embed de inicio al arrancar el bot
- Embed de errores críticos (webhook separado opcional)